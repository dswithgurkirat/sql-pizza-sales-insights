-- Identify the most common pizza size ordered.
select quantity ,count(order_details_id) from orders_details group by quantity;
SELECT 
    pizzas.size, COUNT(orders_details.order_details_id)
FROM
    pizzas
        JOIN
    orders_details ON pizzas.pizza_id = orders_details.pizza_id
GROUP BY pizzas.size;